/**
 * =============================================================================
 * EXPORTACIÓN PDF - FUNCIONALIDADES CORREGIDAS
 * Generación de PDF con formato profesional y logo ACH auténtico
 * =============================================================================
 */

// Función de respaldo para mostrar mensajes si no está definida
if (typeof mostrarMensaje === 'undefined') {
  window.mostrarMensaje = function(mensaje, tipo) {
    if (tipo === 'error') {
      alert('Error: ' + mensaje);
    } else {
      alert(mensaje);
    }
  };
}

// =============================================================================
// UTILIDAD: ESPERAR CARGA DE IMÁGENES
// =============================================================================
function waitForImages(root) {
  const imgs = Array.from((root || document).querySelectorAll('img'));
  if (!imgs.length) return Promise.resolve();
  
  return Promise.all(
    imgs.map(img => {
      if (img.complete && img.naturalWidth) return Promise.resolve();
      return new Promise(res => {
        img.onload = () => res();
        img.onerror = () => res();
      });
    })
  );
}

// =============================================================================
// UTILIDAD: CONVERTIR IMAGEN A BASE64 DESDE ELEMENTO
// =============================================================================
function convertImageToBase64FromElement(imgElement) {
  return new Promise((resolve, reject) => {
    try {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      canvas.width = imgElement.naturalWidth || imgElement.width;
      canvas.height = imgElement.naturalHeight || imgElement.height;
      
      ctx.drawImage(imgElement, 0, 0);
      const dataURL = canvas.toDataURL('image/png');
      resolve(dataURL);
    } catch (error) {
      console.error('Error al convertir imagen a base64:', error);
      reject(error);
    }
  });
}

// =============================================================================
// LOGO ACH COMPLETO CON TEXTO Y COLOMBIA
// =============================================================================
function crearLogoACH_SVG() {
    return `<svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="400px" height="150px" style="shape-rendering:geometricPrecision; text-rendering:geometricPrecision; image-rendering:optimizeQuality; fill-rule:evenodd; clip-rule:evenodd" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1300 500">
<!-- Todos los puntos azules del logo ACH - incluyendo los que van hacia abajo -->
<g><path style="opacity:0.985" fill="#115da8" d="M 309.5,173.5 C 324.515,175.204 329.681,183.204 325,197.5C 316.66,206.464 307.993,206.797 299,198.5C 293.761,186.326 297.261,177.993 309.5,173.5 Z"/></g>
<g><path style="opacity:0.977" fill="#115da7" d="M 251.5,176.5 C 264.743,178.319 268.577,185.319 263,197.5C 258.063,201.722 252.563,202.556 246.5,200C 240.836,194.221 240.003,187.721 244,180.5C 246.255,178.501 248.755,177.168 251.5,176.5 Z"/></g>
<g><path style="opacity:0.979" fill="#115da7" d="M 193.5,179.5 C 202.014,179.843 205.514,184.176 204,192.5C 200.608,198.467 195.774,199.967 189.5,197C 183.393,189.359 184.726,183.526 193.5,179.5 Z"/></g>
<g><path style="opacity:0.986" fill="#115da8" d="M 279.5,217.5 C 295.842,218.846 301.009,227.179 295,242.5C 288.738,248.93 281.571,250.097 273.5,246C 265.865,237.977 265.532,229.644 272.5,221C 274.925,219.787 277.259,218.621 279.5,217.5 Z"/></g>
<g><path style="opacity:0.984" fill="#115da8" d="M 338.5,217.5 C 354.01,218.859 359.177,226.859 354,241.5C 347.206,249.367 339.372,250.534 330.5,245C 323.355,236.022 324.021,227.689 332.5,220C 334.611,219.155 336.611,218.322 338.5,217.5 Z"/></g>
<g><path style="opacity:0.978" fill="#115da8" d="M 221.5,220.5 C 235.399,221.694 239.566,228.694 234,241.5C 229.063,245.722 223.563,246.556 217.5,244C 210.133,237.27 209.8,230.27 216.5,223C 218.315,222.243 219.981,221.41 221.5,220.5 Z"/></g>
<g><path style="opacity:0.972" fill="#115da7" d="M 163.5,223.5 C 173.416,223.998 176.916,228.998 174,238.5C 170.95,242.13 167.117,243.297 162.5,242C 157.268,239.367 155.435,235.201 157,229.5C 158.436,226.558 160.603,224.558 163.5,223.5 Z"/></g>
<g><path style="opacity:0.954" fill="#115da8" d="M 120.5,227.5 C 127.985,228.805 129.319,232.305 124.5,238C 119.201,239.033 116.701,236.866 117,231.5C 117.69,229.65 118.856,228.316 120.5,227.5 Z"/></g>
<g><path style="opacity:0.988" fill="#125ea7" d="M 250.5,263.5 C 259.603,263.04 265.603,267.04 268.5,275.5C 287.491,276.333 306.491,276.833 325.5,277C 335.621,290.077 345.621,303.244 355.5,316.5C 387.161,317.333 418.828,317.833 450.5,318C 447.021,320.312 444.021,323.146 441.5,326.5C 422.167,327.167 402.833,327.833 383.5,328.5C 376.216,343.569 368.549,358.402 360.5,373C 349.167,373.333 337.833,373.667 326.5,374C 320.674,384.827 312.341,387.16 301.5,381C 294.833,373 294.833,365 301.5,357C 311.418,351.052 319.418,352.885 325.5,362.5C 335.149,363.665 344.816,363.832 354.5,363C 360.167,351.333 365.833,339.667 371.5,328C 327.168,327.5 282.835,327.333 238.5,327.5C 237.347,333.484 233.681,336.984 227.5,338C 216.473,338.976 210.14,333.976 208.5,323C 212.123,308.232 220.79,304.232 234.5,311C 235.956,312.745 237.289,314.578 238.5,316.5C 273.167,317.833 307.833,317.833 342.5,316.5C 334.641,306.475 326.975,296.308 319.5,286C 302.167,285.333 284.833,285.333 267.5,286C 261.664,294.696 253.998,296.696 244.5,292C 238.885,287.032 237.052,280.865 239,273.5C 241.194,268.171 245.027,264.838 250.5,263.5 Z"/></g>
<g><path style="opacity:0.984" fill="#115da7" d="M 192.5,266.5 C 204.877,267.256 209.377,273.59 206,285.5C 199.297,293.032 192.297,293.365 185,286.5C 180.72,277.164 183.22,270.498 192.5,266.5 Z"/></g>
<g><path style="opacity:0.97" fill="#115da7" d="M 134.5,269.5 C 145.122,270.41 148.288,275.744 144,285.5C 137.597,290.157 132.263,289.157 128,282.5C 126.493,276.179 128.66,271.846 134.5,269.5 Z"/></g>
<g><path style="opacity:0.944" fill="#115ea7" d="M 91.5,273.5 C 96.757,273.688 98.9237,276.355 98,281.5C 94.6667,285.5 91.3333,285.5 88,281.5C 87.2793,277.946 88.4459,275.28 91.5,273.5 Z"/></g>
<g><path style="opacity:0.987" fill="#115da7" d="M 162.5,310.5 C 176.24,310.988 180.74,317.654 176,330.5C 171.347,335.547 165.847,336.714 159.5,334C 153.593,329.339 152.093,323.505 155,316.5C 157.114,313.879 159.614,311.879 162.5,310.5 Z"/></g>
<g><path style="opacity:0.975" fill="#115da7" d="M 119.5,313.5 C 128.478,313.31 132.311,317.643 131,326.5C 127.608,332.467 122.774,333.967 116.5,331C 110.632,323.851 111.632,318.018 119.5,313.5 Z"/></g>
<g><path style="opacity:0.937" fill="#115ea8" d="M 76.5,317.5 C 82.1573,317.324 84.324,319.991 83,325.5C 80.4192,329.057 77.4192,329.39 74,326.5C 72.7795,322.718 73.6128,319.718 76.5,317.5 Z"/></g>
<g><path style="opacity:0.989" fill="#115da7" d="M 191.5,356.5 C 202.649,356.148 207.816,361.481 207,372.5C 202.842,381.442 196.342,383.608 187.5,379C 180.147,369.931 181.481,362.431 191.5,356.5 Z"/></g>
<g><path style="opacity:0.979" fill="#115da8" d="M 250.5,356.5 C 264.364,357.547 268.53,364.547 263,377.5C 254.916,383.583 247.916,382.583 242,374.5C 239.819,365.868 242.652,359.868 250.5,356.5 Z"/></g>
<g><path style="opacity:0.974" fill="#115da7" d="M 133.5,359.5 C 140.768,358.79 145.101,361.956 146.5,369C 145.411,376.695 141.078,379.695 133.5,378C 128.268,375.367 126.435,371.201 128,365.5C 129.36,362.977 131.193,360.977 133.5,359.5 Z"/></g>
<g><path style="opacity:1" fill="#125da7" d="M 91.5,363.5 C 98.6033,364.867 99.9366,368.367 95.5,374C 90.2005,375.033 87.7005,372.866 88,367.5C 88.6897,365.65 89.8564,364.316 91.5,363.5 Z"/></g>
<g><path style="opacity:0.955" fill="#115da7" d="M 162.5,403.5 C 168.766,402.117 172.433,404.45 173.5,410.5C 172.592,416.959 168.926,419.459 162.5,418C 157.235,413.076 157.235,408.242 162.5,403.5 Z"/></g>
<g><path style="opacity:0.932" fill="#115da8" d="M 119.5,405.5 C 125.665,404.829 128.165,407.496 127,413.5C 122.301,417.824 118.801,416.99 116.5,411C 117.124,408.915 118.124,407.082 119.5,405.5 Z"/></g>
<g><path style="opacity:0.976" fill="#115da8" d="M 191.5,445.5 C 202.379,445.204 206.212,450.204 203,460.5C 196.113,466.193 190.446,465.193 186,457.5C 185.056,452.146 186.889,448.146 191.5,445.5 Z"/></g>

<!-- Letra "a" del logo -->
<g><path style="opacity:0.987" fill="#115da7" d="M 460.5,249.5 C 485.169,249.333 509.836,249.5 534.5,250C 552.523,254.868 561.857,266.701 562.5,285.5C 556.86,319.2 551.027,352.866 545,386.5C 544.813,390.039 543.646,393.205 541.5,396C 513.587,397.649 485.587,397.983 457.5,397C 435.127,389.439 426.294,373.939 431,350.5C 437.816,329.348 451.983,316.181 473.5,311C 496.894,311.152 520.061,310.318 543,308.5C 544.36,301.532 545.527,294.532 546.5,287.5C 545.66,275.302 539.327,267.802 527.5,265C 504.833,264.667 482.167,264.333 459.5,264C 455.326,258.882 455.66,254.049 460.5,249.5 Z M 475.5,325.5 C 496.833,325.5 518.167,325.5 539.5,325.5C 536.608,344.516 533.608,363.516 530.5,382.5C 509.164,382.667 487.831,382.5 466.5,382C 448.174,377.187 442.007,365.687 448,347.5C 453.846,335.802 463.013,328.468 475.5,325.5 Z"/></g>

<!-- Letra "c" del logo -->
<g><path style="opacity:0.982" fill="#115da7" d="M 616.5,249.5 C 642.502,249.333 668.502,249.5 694.5,250C 698.393,252.693 699.226,256.193 697,260.5C 695.786,262.049 694.286,263.215 692.5,264C 668.5,264.333 644.5,264.667 620.5,265C 604.244,268.035 594.077,277.535 590,293.5C 586.113,315.324 582.279,337.158 578.5,359C 579.188,371.396 585.521,379.063 597.5,382C 622.167,382.333 646.833,382.667 671.5,383C 675.618,387.88 675.284,392.547 670.5,397C 660.403,398.13 650.236,398.63 640,398.5C 623.488,398.4 606.988,397.9 590.5,397C 572.705,392.196 563.371,380.529 562.5,362C 566.537,334.611 571.704,307.445 578,280.5C 586.248,264.414 599.081,254.081 616.5,249.5 Z"/></g>

<!-- Letra "h" del logo -->
<g><path style="opacity:0.987" fill="#115da7" d="M 725.5,186.5 C 731.992,184.723 735.659,187.056 736.5,193.5C 732.45,214.801 728.95,236.135 726,257.5C 731.422,254.039 737.255,251.539 743.5,250C 761.5,249.333 779.5,249.333 797.5,250C 811.631,253.464 820.465,262.298 824,276.5C 824.667,282.167 824.667,287.833 824,293.5C 818.215,326.875 812.215,360.208 806,393.5C 802.692,397.327 798.526,398.494 793.5,397C 791.556,395.278 790.556,393.111 790.5,390.5C 796.5,356.167 802.5,321.833 808.5,287.5C 807.382,276.217 801.382,269.051 790.5,266C 775.5,265.333 760.5,265.333 745.5,266C 730.923,269.578 722.09,278.744 719,293.5C 713.322,326.569 707.322,359.569 701,392.5C 698.103,397.155 693.937,398.655 688.5,397C 687.299,396.097 686.465,394.931 686,393.5C 696.626,325.699 708.292,258.032 721,190.5C 722.397,188.93 723.897,187.596 725.5,186.5 Z"/></g>

<!-- Texto "COLOMBIA" con el mismo estilo que "ach" pero más a la derecha -->
<text x="560" y="430" font-family="Arial, sans-serif" font-size="36" fill="#115da8" font-weight="300" letter-spacing="6">C O L O M B I A</text>

<!-- Texto "El Motor de las Transacciones Electrónicas" más abajo y sin línea divisoria -->
<text x="910" y="320" font-family="Arial, sans-serif" font-size="28" fill="#a4a7aa" font-style="italic" font-weight="300">
  <tspan x="910" dy="0">El Motor de las</tspan>
  <tspan x="910" dy="35">Transacciones</tspan>
  <tspan x="910" dy="35">Electrónicas</tspan>
</text>

</svg>`;
}

// =============================================================================
// GENERAR CONTENIDO DE EVIDENCIAS
// =============================================================================
function generarContenidoEvidencias() {
  // console.log('Generando evidencias...');
  // console.log('checklistItems tipo:', typeof window.checklistItems);
  // console.log('checklistItems valor:', window.checklistItems);
  // console.log('tipoChecklistActual tipo:', typeof window.tipoChecklistActual);
  // console.log('tipoChecklistActual valor:', window.tipoChecklistActual);
  // console.log('camposEstado tipo:', typeof window.camposEstado);
  // console.log('camposEstado valor:', window.camposEstado);
  
  // Usar tipoChecklistActual en lugar de checklistItems
  const checklistActual = window.tipoChecklistActual || window.checklistItems;
  if (!checklistActual || !Array.isArray(checklistActual)) {
    console.warn('checklistActual no está definido como array válido');
    return `
      <div style="text-align: center; padding: 40px; color: #666;">
        <h3>No se encontraron evidencias para mostrar</h3>
        <p>Asegúrate de completar el checklist antes de generar el PDF.</p>
        <p style="font-size: 12px; color: #999;">Debug: checklistActual = ${typeof checklistActual}</p>
      </div>
    `;
  }

  let contenido = `
    <div class="evidencias-section">
      <h2 style="
        color: #115da8;
        font-size: 24px;
        margin-bottom: 30px;
        padding-bottom: 10px;
        border-bottom: 2px solid #e0e0e0;
      ">📋 Evidencias de Certificación</h2>
  `;

  // Obtener información de la empresa desde DOM o camposEstado
  let empresaInfo = {};
  try {
    if (window.camposEstado && typeof window.camposEstado === 'object') {
      empresaInfo = {
        nombre: window.camposEstado['razon-social']?.valor || 'Empresa no especificada',
        nit: window.camposEstado['nit']?.valor || 'NIT no especificado',  
        email: window.camposEstado['email']?.valor || 'Email no especificado',
        telefono: window.camposEstado['telefono']?.valor || 'Teléfono no especificado'
      };
    } else {
      // Obtener desde DOM como alternativa
      empresaInfo = {
        nombre: document.getElementById('razon-social')?.value || 'Empresa no especificada',
        nit: document.getElementById('nit')?.value || 'NIT no especificado',
        email: document.getElementById('email')?.value || 'Email no especificado',
        telefono: document.getElementById('telefono')?.value || 'Teléfono no especificado'
      };
    }
  } catch (error) {
    console.warn('Error obteniendo datos empresa:', error);
    empresaInfo = {
      nombre: 'Empresa no especificada',
      nit: 'NIT no especificado',
      email: 'Email no especificado',
      telefono: 'Teléfono no especificado'
    };
  }

  // Información de la empresa
  contenido += `
    <div class="empresa-info" style="
      background: #f8f9fa;
      padding: 20px;
      border-radius: 8px;
      margin-bottom: 30px;
      border-left: 4px solid #115da8;
    ">
      <h3 style="margin: 0 0 15px 0; color: #115da8;">🏢 Información de la Empresa</h3>
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
        <div><strong>Razón Social:</strong> ${empresaInfo.nombre}</div>
        <div><strong>NIT:</strong> ${empresaInfo.nit}</div>
        <div><strong>Email:</strong> ${empresaInfo.email}</div>
        <div><strong>Teléfono:</strong> ${empresaInfo.telefono}</div>
      </div>
    </div>
  `;

  // Estadísticas del checklist
  const totalItems = checklistActual.length;
  const completedItems = checklistActual.filter(item => item.completed).length;
  const pendingItems = totalItems - completedItems;
  const completionPercentage = totalItems > 0 ? Math.round((completedItems / totalItems) * 100) : 0;

  contenido += `
    <div class="estadisticas" style="
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 15px;
      margin-bottom: 30px;
    ">
      <div style="text-align: center; padding: 15px; background: #e8f5e8; border-radius: 8px;">
        <div style="font-size: 24px; font-weight: bold; color: #28a745;">${completedItems}</div>
        <div style="font-size: 12px; color: #666;">Completados</div>
      </div>
      <div style="text-align: center; padding: 15px; background: #fff3cd; border-radius: 8px;">
        <div style="font-size: 24px; font-weight: bold; color: #ffc107;">${pendingItems}</div>
        <div style="font-size: 12px; color: #666;">Pendientes</div>
      </div>
      <div style="text-align: center; padding: 15px; background: #d1ecf1; border-radius: 8px;">
        <div style="font-size: 24px; font-weight: bold; color: #17a2b8;">${totalItems}</div>
        <div style="font-size: 12px; color: #666;">Total</div>
      </div>
      <div style="text-align: center; padding: 15px; background: #d4edda; border-radius: 8px;">
        <div style="font-size: 24px; font-weight: bold; color: #155724;">${completionPercentage}%</div>
        <div style="font-size: 12px; color: #666;">Completitud</div>
      </div>
    </div>
  `;

  // Lista detallada de evidencias
  contenido += `
    <div class="lista-evidencias">
      <h3 style="color: #115da8; margin-bottom: 20px;">📝 Detalle de Evidencias</h3>
  `;

  checklistActual.forEach((item, index) => {
    const statusIcon = item.completed ? '✅' : '⏳';
    const statusColor = item.completed ? '#28a745' : '#ffc107';
    const statusText = item.completed ? 'Completado' : 'Pendiente';
    
    contenido += `
      <div class="evidencia-item" style="
        border: 1px solid #e0e0e0;
        border-radius: 8px;
        margin-bottom: 15px;
        padding: 15px;
        background: ${item.completed ? '#f8fff8' : '#fffef8'};
      ">
        <div style="display: flex; align-items: center; margin-bottom: 10px;">
          <span style="font-size: 20px; margin-right: 10px;">${statusIcon}</span>
          <div style="flex-grow: 1;">
            <h4 style="margin: 0; color: #333;">${item.text}</h4>
            <div style="font-size: 12px; color: ${statusColor}; font-weight: bold;">${statusText}</div>
          </div>
        </div>
        
        ${item.description ? `
          <div style="
            background: white;
            padding: 10px;
            border-radius: 4px;
            border-left: 3px solid ${statusColor};
            margin-top: 10px;
            font-size: 13px;
            color: #666;
          ">
            <strong>Descripción:</strong> ${item.description}
          </div>
        ` : ''}
        
        ${item.completed && item.completedDate ? `
          <div style="
            font-size: 11px;
            color: #666;
            text-align: right;
            margin-top: 8px;
          ">
            Completado el: ${new Date(item.completedDate).toLocaleDateString('es-CO')}
          </div>
        ` : ''}
      </div>
    `;
  });

  contenido += `
      </div>
    </div>
  `;

  return contenido;
}

// =============================================================================
// TEMPLATE DEL PDF
// =============================================================================
function createPDFTemplate() {
  const fechaActual = new Date().toLocaleDateString('es-CO', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return `
    <div class="pdf-container" style="
      width: 794px;
      min-height: 1123px;
      padding: 40px;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: white;
      color: #333;
      box-sizing: border-box;
      margin: 0 auto;
    ">
      <!-- Encabezado con logo ACH -->
      <div class="pdf-header" style="
        display: grid;
        grid-template-columns: 200px 1fr 200px;
        gap: 20px;
        align-items: center;
        margin-bottom: 40px;
        padding-bottom: 20px;
        border-bottom: 2px solid #e0e0e0;
      ">
        <div class="col-logo" style="
          display: flex;
          justify-content: flex-start;
          align-items: center;
        ">
          ${crearLogoACH_SVG()}
        </div>
        
        <div class="col-title" style="
          text-align: center;
        ">
          <h1 style="
            margin: 0;
            font-size: 28px;
            font-weight: 700;
            color: #115da8;
            text-transform: uppercase;
            letter-spacing: 1px;
          ">
            Certificado de Comercio
          </h1>
          <p style="
            margin: 5px 0 0 0;
            font-size: 14px;
            color: #666;
            font-weight: 400;
          ">
            Portal de Certificación - ACH Colombia
          </p>
        </div>
        
        <div class="col-empresa" style="
          text-align: right;
          font-size: 12px;
          color: #666;
        ">
          <div style="margin-bottom: 5px;">
            <strong>Fecha:</strong><br>
            ${fechaActual}
          </div>
        </div>
      </div>

      <!-- Contenido del PDF -->
      <div class="pdf-content" style="
        font-size: 14px;
        line-height: 1.6;
        color: #444;
      ">
        <div id="contenido-evidencias">
          ${generarContenidoEvidencias()}
        </div>
      </div>
    </div>
  `;
}

// =============================================================================
// FUNCIÓN DE EXPORTACIÓN PRINCIPAL
// =============================================================================
async function exportarPDF(titulo = "Reporte de Certificación") {
  try {
    mostrarMensaje('Generando PDF...', 'info');

    // Crear contenido del PDF
    const htmlContent = createPDFTemplate();
    
    // Crear elemento temporal para renderizado
    const tempDiv = document.createElement('div');
    tempDiv.style.position = 'absolute';
    tempDiv.style.top = '-10000px';
    tempDiv.style.left = '0';
    tempDiv.style.width = '794px';
    tempDiv.style.zIndex = '-1';
    tempDiv.innerHTML = htmlContent;
    document.body.appendChild(tempDiv);

    // Esperar a que carguen las imágenes
    await waitForImages(tempDiv);

    // Generar canvas con html2canvas - Configuración optimizada para SVG
    const canvas = await html2canvas(tempDiv, {
      scale: 3, // Aumentar escala para mejor calidad del SVG
      backgroundColor: '#ffffff',
      useCORS: true,
      allowTaint: false,
      foreignObjectRendering: false, // Desactivar para SVG complejo
      windowWidth: 800,
      windowHeight: 300,
      scrollY: -window.scrollY,
      imageTimeout: 15000,
      logging: false,
      ignoreElements: function(element) {
        return false; // No ignorar ningún elemento
      },
      onclone: function(clonedDoc) {
        console.log('=== ONCLONE EJECUTÁNDOSE ===');
        
        // Copiar variables globales al contexto clonado
        if (clonedDoc.defaultView && window.checklistItems) {
          clonedDoc.defaultView.checklistItems = JSON.parse(JSON.stringify(window.checklistItems));
          console.log('checklistItems copiado:', clonedDoc.defaultView.checklistItems);
        }
        
        if (clonedDoc.defaultView && window.tipoChecklistActual) {
          clonedDoc.defaultView.tipoChecklistActual = JSON.parse(JSON.stringify(window.tipoChecklistActual));
          console.log('tipoChecklistActual copiado:', clonedDoc.defaultView.tipoChecklistActual);
        }
        
        if (clonedDoc.defaultView && window.camposEstado) {
          clonedDoc.defaultView.camposEstado = JSON.parse(JSON.stringify(window.camposEstado));
          console.log('camposEstado copiado:', clonedDoc.defaultView.camposEstado);
        }
        
        // También copiar las funciones necesarias
        if (clonedDoc.defaultView) {
          clonedDoc.defaultView.generarContenidoEvidencias = generarContenidoEvidencias;
        }
        
        // Ejecutar la función generarContenidoEvidencias en el contexto clonado
        try {
          const contenidoElemento = clonedDoc.querySelector('#contenido-evidencias');
          if (contenidoElemento && clonedDoc.defaultView.checklistItems) {
            // console.log('Regenerando contenido de evidencias en contexto clonado...');
            const nuevoContenido = clonedDoc.defaultView.generarContenidoEvidencias();
            contenidoElemento.innerHTML = nuevoContenido;
            // console.log('Contenido regenerado exitosamente');
          }
        } catch (error) {
          console.error('Error regenerando evidencias:', error);
        }
        
        // Configuración específica para SVG del logo
        const svgs = clonedDoc.querySelectorAll('svg');
        svgs.forEach(svg => {
          // Mantener dimensiones fijas para el logo
          svg.style.width = '200px';
          svg.style.height = '107px';
          svg.style.display = 'block';
          svg.style.visibility = 'visible';
          svg.style.opacity = '1';
          
          // Asegurar namespace y atributos
          svg.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
          svg.setAttribute('width', '200');
          svg.setAttribute('height', '107');
          
          // Forzar visibilidad de todos los paths y grupos
          const allElements = svg.querySelectorAll('g, path, text, circle, line, rect');
          allElements.forEach(el => {
            el.style.display = 'block';
            el.style.visibility = 'visible';
            if (!el.style.opacity) el.style.opacity = '1';
          });
        });
        
        // Asegurar que el contenedor del logo sea visible
        const logoContainer = clonedDoc.querySelector('.col-logo');
        if (logoContainer) {
          logoContainer.style.display = 'flex';
          logoContainer.style.visibility = 'visible';
          logoContainer.style.opacity = '1';
        }

        // Asegurar que las variables globales estén disponibles
        clonedDoc.defaultView.checklistItems = window.checklistItems;
        clonedDoc.defaultView.tipoChecklistActual = window.tipoChecklistActual;
        clonedDoc.defaultView.camposEstado = window.camposEstado;
      }
    });

    // Crear PDF - Sintaxis compatible con jsPDF 2.5.1
    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF('p', 'pt', 'a4');
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const margin = 40;
    const imgWidth = pageWidth - margin * 2;
    let y = 0;
    let page = 0;
    const maxPageHeight = pageHeight - margin * 2;

    // Dividir contenido en páginas
    const canvasHeight = canvas.height;
    const pageCanvasHeight = (maxPageHeight * canvas.width) / imgWidth;

    while (y < canvasHeight) {
      if (page > 0) {
        pdf.addPage();
      }

      // Crear canvas para esta página
      const pageCanvas = document.createElement('canvas');
      pageCanvas.width = canvas.width;
      pageCanvas.height = Math.min(pageCanvasHeight, canvasHeight - y);

      const pageCtx = pageCanvas.getContext('2d');
      pageCtx.drawImage(canvas, 0, y, canvas.width, pageCanvas.height, 0, 0, canvas.width, pageCanvas.height);

      // Agregar imagen al PDF
      const imgData = pageCanvas.toDataURL('image/png', 1.0);
      const imgHeight = (pageCanvas.height * imgWidth) / pageCanvas.width;

      pdf.addImage(imgData, 'PNG', margin, margin, imgWidth, imgHeight, '', 'FAST');

      y += pageCanvasHeight;
      page++;
    }

    // Limpiar elemento temporal
    document.body.removeChild(tempDiv);

    // Descargar PDF
    const nombreArchivo = `${titulo.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_${new Date().toISOString().split('T')[0]}.pdf`;
    pdf.save(nombreArchivo);

    mostrarMensaje('PDF generado exitosamente', 'success');

  } catch (error) {
    console.error('Error al generar PDF:', error);
    mostrarMensaje('Error al generar el PDF: ' + error.message, 'error');
  }
}

// =============================================================================
// HACER FUNCIÓN DISPONIBLE GLOBALMENTE
// =============================================================================
window.exportarPDF = exportarPDF;
